<?php
/* Teacher accounts, like pupil accounts: BULIG makes the Teacher ID and a starter password and prints a Teacher Pass
   with a QR code. The first scan signs the teacher in; then BULIG asks for their own password before anything else.
   After that the QR code only fills in the Teacher ID, so a lost pass cannot open a teacher's pupils.
   Admins can also add a whole list of teachers from a CSV or Excel file. Uses the table from 018_pupil_cards.sql. */
const TEACHER_ACCOUNT_ACTIONS=['first_password','admin_teacher_starter','timport_preview','timport_confirm','timport_typed','timport_cancel'];

/** Still on the starter password: the teacher makes their own before using BULIG. */
function teacher_must_change(?array $u):bool{return $u!==null&&$u['role']==='teacher'&&card_has_starter((int)$u['id']);}
/** The pupil or teacher a scanned sign-in key belongs to. */
function card_user_any(string $key):?array{
 if(!cards_ready()||!preg_match('~^[A-Za-z0-9_-]{20,40}$~',$key))return null;
 return one("SELECT u.* FROM pupil_cards c JOIN users u ON u.id=c.user_id WHERE c.key_hash=? AND u.role IN ('pupil','teacher','admin') AND u.active=1",[hash('sha256',$key)])?:null;   // v211 every ID card signs in
}
/** The teacher sign-in form with the Teacher ID filled in. */
function teacher_login_url(array $t):string{return '?page=login&role=teacher&form=1&id='.rawurlencode((string)$t['public_id']);}
function teacher_char(int $id,string $pose='hello'):string{return char_src(tf_is_male($id)?'teacher-male':'teacher-female',$pose);}
/** "Grade 4 · Silang" (and "+1 more") for a teacher's pass. */
function teacher_sections_label(int $id):string{
 $s=rows('SELECT grade_level,name FROM sections s WHERE s.teacher_id=?'.(sections_archive_supported()?' AND s.archived_at IS NULL':'').' ORDER BY grade_level,name',[$id]);
 return $s?'Grade '.(int)$s[0]['grade_level'].' · '.$s[0]['name'].(count($s)>1?' +'.(count($s)-1).' more':''):'';
}

/** A new teacher: a Teacher ID (PCEST0001), a starter password and a Teacher Pass key. Call inside a transaction. */
function teacher_create(string $name,string $sex):array{
 $public=new_account_id('teacher');
 q('INSERT INTO users(public_id,role,name,password_hash) VALUES(?,?,?,?)',[$public,'teacher',$name,password_hash(bin2hex(random_bytes(16)),PASSWORD_DEFAULT)]);$id=(int)db()->lastInsertId();school_mark_user($id);
 q('INSERT INTO teachers VALUES(?)',[$id]);tf_set_sex($id,$sex);
 $card=card_issue($id,true);
 notify($id,'account','Welcome to BULIG Quest, '.explode(' ',trim($name))[0].'!','Start by adding a section, then your pupils.','?page=sections');
 return ['id'=>$id,'public'=>$public,'pw'=>$card['pw']];
}

/** One Teacher Pass: the same ticket as the pupils' Reading Pass, for a teacher. */
function teacher_ticket_html(array $t,?string $key,?string $pw,int $n):string{   // v211 an ID card (pupils keep tickets)
 $qr=$key?'?page=login&key='.rawurlencode($key):teacher_login_url($t);$sec=(string)($t['sections']??'');
 $sch=(int)val('SELECT COALESCE(school_id,0) FROM users WHERE id=?',[(int)$t['id']]);$sn=$sch?(string)(val("SELECT COALESCE(NULLIF(name,''),code) FROM schools WHERE id=?",[$sch])?:''):'';
 return staff_id_card(['school'=>$sch,'name'=>(string)$t['name'],'role'=>'Teacher','place'=>trim($sn.($sn!==''&&$sec!==''?' · ':'').$sec),'id'=>$t['public_id'],'pw'=>$pw,'qr'=>$qr,'pic'=>function_exists('staff_pic')?staff_pic((int)$t['id'],'teacher'):teacher_char((int)$t['id']),'scan'=>$key?'Scan to sign in':'Scan to open BULIG Quest','n'=>$n]);
}

/** Admin Pass (v172): the administrator's own card. Its QR code only fills in the admin ID on the sign-in page; the
    password and the PIN are always typed, so a lost Admin Pass never signs anyone in. */
function admin_pass_view(array $u):void{
 $n=0;echo '<div class="pageheading ws-head no-print"><div><span class="eyebrow">PRINT & DOWNLOAD</span><h1>Admin Pass</h1><p class="muted">Scan it on the sign-in page of a phone to fill in your administrator ID. You still type your password.</p></div><div class="ws-btns"><a class="btn secondary" href="?page=print">'.icon('arrow','flip').'Back</a></div></div>';
 echo '<div class="lc-tools no-print card"><button type="button" class="btn primary" data-lc-print>'.icon('download').'<span data-lc-print-label>Print pass</span></button></div><div class="lc-sheet tk-sheet idc-sheet" data-lc-sheet data-tk-word="pass">';
 foreach(rows("SELECT id,name,public_id FROM users WHERE role='admin' AND active=1 AND id=?",[(int)$u['id']]) as $a){$n++;$qr=function_exists('staff_qr')?staff_qr((int)$a['id'],(string)$a['public_id']):'?page=login&id='.rawurlencode((string)$a['public_id']);
  echo '<div class="tk-wrap idc-wrap" data-tk>'.staff_id_card(['school'=>isset($u['active_role'])&&function_exists('role_place_ids')?role_place_ids($u['active_role'],(int)($u['scope_id']??0))[0]:0,'muni'=>isset($u['active_role'])&&function_exists('role_place_ids')?role_place_ids($u['active_role'],(int)($u['scope_id']??0))[1]:0,'name'=>(string)$a['name'],'role'=>function_exists('rbac_ready')&&isset($u['active_role'])&&isset(ROLES[$u['active_role']])?ROLES[$u['active_role']][0]:'Administrator','place'=>function_exists('rbac_scope_name')&&isset($u['active_role'])?rbac_scope_name($u['active_role'],(int)($u['scope_id']??0)):'','id'=>$a['public_id'],'pw'=>null,'qr'=>$qr,'pic'=>function_exists('staff_pic')?staff_pic((int)$a['id'],'admin'):char_src(tf_is_male((int)$a['id'])?'admin-male':'admin-female','hello'),'scan'=>'Scan to sign in','n'=>$n]).'<div class="tk-bar no-print"><label class="tk-sel"><input type="checkbox" data-tk-pick checked> Print</label></div></div>';}
 echo '</div><script src="'.asset_url('qrcode.js').'" defer></script><script src="'.asset_url('cards.js').'" defer></script>';
}

/** Right after the admin adds a teacher: a window with the new account and its Teacher Pass, ready to print. */
function new_teacher_overlay(int $tid):string{
 $t=one("SELECT id,name,public_id FROM users WHERE id=? AND role='teacher'",[$tid]);if(!$t||!cards_ready())return '';
 $t['sections']=teacher_sections_label($tid);$info=card_info($tid);$pw=$info['pw']??null;$first=explode(' ',trim((string)$t['name']))[0];
 return '<div class="np-ov" data-np role="dialog" aria-modal="true" aria-labelledby="np-title"><div class="np-box"><button type="button" class="np-x" data-np-close aria-label="Close">'.icon('close').'</button>'
  .'<div class="np-top"><span class="np-ok">'.icon('check').'</span><div><h2 id="np-title">'.e($first).' is ready!</h2><p class="muted">Give this Teacher Pass to '.e($first).'. One scan of the QR code signs them in, then BULIG Quest asks them to make their own password right away.</p></div></div>'
  .'<div class="np-ticket">'.teacher_ticket_html($t,$info['key'],$pw,1).'</div>'
  .'<div class="np-facts"><div><span>Teacher ID</span><b>'.e($t['public_id']).'</b></div>'.($pw!==null?'<div><span>Starter password</span><b>'.e($pw).'</b></div>':'').'</div>'
  .'<div class="np-acts"><button type="button" class="btn primary" data-np-print>'.icon('download').'Print this pass</button><button type="button" class="btn secondary" data-np-add>'.icon('user').'Add another teacher</button><a class="btn secondary" href="?page=teacher_cards">'.icon('key').'All Teacher Passes</a><button type="button" class="btn quiet" data-np-close>Done</button></div></div></div>'
  .'<script src="'.asset_url('qrcode.js').'" defer></script><script src="'.asset_url('cards.js').'" defer></script>';
}

/** Teachers who still use a starter password (their pass shows it). */
function teacher_starter_ids():array{if(!cards_ready())return [];return array_map('intval',array_column(rows("SELECT c.user_id FROM pupil_cards c JOIN users u ON u.id=c.user_id AND u.role='teacher' WHERE c.starter_enc IS NOT NULL"),'user_id'));}
function teacher_needs_018():string{return '<section class="card"><div class="ws-hd"><h2>'.icon('alert').' One database file is needed first</h2></div><p>Teacher Passes and starter passwords use the same table as the pupils’ Reading Pass. Import <b>database/migrations/018_pupil_cards.sql</b> once in phpMyAdmin, then come back to this page.</p></section>';}

/** Printable Teacher Passes, and who still uses a starter password. */
function teacher_cards_view():void{
 $one=(int)($_GET['t']??0);$show=(string)($_GET['show']??'all');$new=isset($_GET['new'])?array_map('intval',array_column($_SESSION['teacher_import_done']??[],'uid')):[];
 echo '<div class="pageheading ws-head no-print"><div><span class="eyebrow">TEACHERS</span><h1>Teacher Passes</h1><p class="muted">Print, cut along the dashed lines and give each teacher their pass. Up to '.idc_per()['s'].' fit on one A4 sheet.</p></div><div class="ws-btns"><a class="btn secondary" href="?page=accounts">'.icon('arrow','flip').'Back to teachers</a></div></div>';
 if(!cards_ready()){echo teacher_needs_018();return;}
 $starter=teacher_starter_ids();$logins=admin_last_logins();
 $all=rows("SELECT id,name,public_id FROM users u WHERE role='teacher' AND active=1".school_users_sql()." ORDER BY name");echo school_filter_bar('teacher_cards');
 $list=array_values(array_filter($all,fn($t)=>$one?(int)$t['id']===$one:($new?in_array((int)$t['id'],$new,true):($show!=='starter'||in_array((int)$t['id'],$starter,true)))));
 echo '<div class="lc-tools no-print card"><form method="get" class="lc-filter"><input type="hidden" name="page" value="teacher_cards"><label>Teachers<select name="show" data-autosubmit><option value="all"'.($show==='all'&&!$one&&!$new?' selected':'').'>Everyone · '.count($all).' teacher'.(count($all)===1?'':'s').'</option><option value="starter"'.($show==='starter'&&!$one&&!$new?' selected':'').'>Still on a starter password · '.count(array_intersect(array_map('intval',array_column($all,'id')),$starter)).'</option>'.($one||$new?'<option value="pick" selected>'.($one?'One teacher':'Just added · '.count($new)).'</option>':'').'</select></label><noscript><button class="btn quiet">Show</button></noscript></form>';
 echo '<label class="lc-opt"><input type="checkbox" data-lc-toggle="lc-hide-qr" checked> QR code</label><label class="lc-opt"><input type="checkbox" data-lc-toggle="lc-hide-pass" checked> Starter password</label><button type="button" class="btn primary" data-lc-print>'.icon('download').'<span data-lc-print-label>Print passes</span></button></div>';
 if(!$list){echo '<section class="empty no-print">'.icon('people').'<h2>No teachers here.</h2><p>'.($show==='starter'?'Every teacher has made their own password.':'Add teachers on the Teachers page, then come back to print their passes.').'</p></section>';}
 else{
  if(function_exists('id_design_picker'))echo id_design_picker('teacher_cards');
  echo '<p class="lc-note no-print">The QR code signs the teacher in, even after they make their own password. Lost a card? Use “New starter password”: the old password and the old QR code stop working.</p>';
  echo '<div class="lc-pick no-print card"><span class="lc-count" data-tk-count>'.count($list).' of '.count($list).' passes selected</span><button type="button" class="btn secondary" data-tk-all>Select all</button><button type="button" class="btn secondary" data-tk-none>Select none</button>'
   .'<span class="lc-size">Pass size<span class="st-seg" role="radiogroup" aria-label="Pass size"><button type="button" class="st-seg-b" role="radio" aria-checked="false" data-tk-size="s">Small<small>'.idc_per()['s'].' per page</small></button><button type="button" class="st-seg-b" role="radio" aria-checked="false" data-tk-size="m">Medium<small>'.idc_per()['m'].' per page</small></button><button type="button" class="st-seg-b" role="radio" aria-checked="false" data-tk-size="l">Large<small>'.idc_per()['l'].' per page</small></button></span></span>'.tk_save_button().'</div>';
  echo '<div class="lc-sheet tk-sheet idc-sheet" data-lc-sheet data-tk-word="pass" data-tk-per="'.e(json_encode(idc_per())).'">';$n=0;
  foreach($list as $t){$n++;$tid=(int)$t['id'];$t['sections']=teacher_sections_label($tid);$info=card_info($tid);
   echo '<div class="tk-wrap idc-wrap" data-tk>'.teacher_ticket_html($t,$info['key'],$info['pw'],$n).'<div class="tk-bar no-print"><label class="tk-sel"><input type="checkbox" data-tk-pick checked> Print</label>'
    .'<form method="post" class="tk-new">'.csrf_field().'<input type="hidden" name="action" value="admin_teacher_starter"><input type="hidden" name="id" value="'.$tid.'"><input type="hidden" name="back" value="cards"><button class="btn quiet" data-confirm="Make a new starter password for '.e($t['name']).'? Their old password and QR code stop working, and they make a new password at the next sign-in.">'.icon('replay').'New starter password</button></form></div></div>';}
  echo '</div>';
 }
 echo '<section class="card no-print tc-pw"><div class="ws-hd"><h2>'.icon('key').' Passwords</h2><small class="muted">Who still uses a starter password</small></div><div class="tablewrap"><table class="ws-table"><thead><tr><th>Teacher</th><th>Password</th><th>Last sign-in</th></tr></thead><tbody>';
 foreach($all as $t){$st=in_array((int)$t['id'],$starter,true);echo '<tr><td><strong>'.e($t['name']).'</strong><small>'.e($t['public_id']).'</small></td><td><span class="ws-pill '.($st?'warn':'ok').'">'.($st?'Starter · must change':'Own password').'</span></td><td>'.e(admin_when($logins[(int)$t['id']]??null)).'</td></tr>';}
 if(!$all)echo '<tr><td colspan="3">No teachers yet.</td></tr>';
 echo '</tbody></table></div></section><script src="'.asset_url('qrcode.js').'" defer></script><script src="'.asset_url('cards.js').'" defer></script>';
}

/* ---------- Add many teachers from a CSV or Excel file ---------- */
function teacher_import_check(array $rows):array{
 $hi=null;foreach(array_slice($rows,0,10,true) as $i=>$r){$c=import_columns($r);if(isset($c['name'])||isset($c['last'])||isset($c['first'])){$hi=$i;$cols=$c;break;}}
 if($hi===null)fail('No header row found. The first row must have column names: Last name, First name, Middle name and Sex. Download the template to see the format.');
 $have=[];foreach(rows("SELECT public_id,name FROM users WHERE role='teacher'") as $t)$have[ck_name_key((string)$t['name'])]=$t['public_id'];
 $taken=[];foreach(rows('SELECT s.grade_level,s.name,u.name tname FROM sections s JOIN users u ON u.id=s.teacher_id WHERE 1'.(sections_archive_supported()?' AND s.archived_at IS NULL':'')) as $s)$taken[mb_strtolower(trim((string)$s['name'])).'|'.(int)$s['grade_level']]=$s['tname'];
 $out=[];$seen=[];
 foreach(array_slice($rows,$hi+1) as $n=>$r){
  $get=fn($k)=>isset($cols[$k])?trim((string)($r[$cols[$k]]??'')):'';
  if(!array_filter($r,fn($c)=>trim((string)$c)!==''))continue;
  if(count($out)>=IMPORT_MAX_ROWS)fail('A teacher list can have up to '.IMPORT_MAX_ROWS.' teachers per upload. Split the file and upload it in parts.');
  $name=$get('name');
  if($name!==''&&substr_count($name,',')===1){[$l,$f]=array_map('trim',explode(',',$name));if($l!==''&&$f!=='')$name=$f.' '.$l;}
  $ext=name_ext_norm($get('ext'));$parts=null;
  if($name===''){[$f,$m,$l]=[import_name_case($get('first')),import_name_case($get('middle')),import_name_case($get('last'))];$name=name_compose($f,$m,$l,(string)$ext);if($f!==''&&$l!=='')$parts=[$f,$m,$l,(string)$ext];}
  else $name=trim(import_name_case($name).' '.$ext);
  $name=trim(preg_replace('/\s+/',' ',$name));$sexRaw=strtolower($get('sex'));
  $sex=in_array($sexRaw,['m','male','lalaki','l'],true)?'male':(in_array($sexRaw,['f','female','babae','b'],true)?'female':null);
  $row=['line'=>$hi+$n+2,'name'=>$name,'parts'=>$parts,'sex'=>$sex,'grade'=>0,'section'=>'','status'=>'ok','notes'=>[]];
  $err=function(string $m)use(&$row){$row['status']='error';$row['notes'][]=$m;};
  if(mb_strlen($name)<2||mb_strlen($name)>150)$err('Name is missing or too long.');
  if($ext===null)$err('Extension must be Jr., Sr., II, III, IV or V (or blank).');
  if(!$sex)$err($sexRaw===''?'Sex is missing (M or F).':'Sex must be M or F.');
  $grade=$get('grade');$grade=$grade!==''?(int)preg_replace('/\D/','',$grade):0;$sec=$get('section');
  if($sec!==''){
   if(grade_ok($grade)){$row['grade']=$grade;$row['section']=mb_substr(import_name_case($sec),0,80);$k=mb_strtolower($row['section']).'|'.$grade;if(isset($taken[$k]))$row['notes'][]='Another teacher ('.$taken[$k].') already has Grade '.$grade.' – '.$row['section'].'.';}
   else $err('Add a Grade from 1 to 10 for the section, or leave Section blank.');
  }elseif($grade)$row['notes'][]='Grade without a Section is left out.';
  if($row['status']==='ok'){$k=ck_name_key($name);
   if(isset($have[$k])){$row['status']='skip';$row['notes']=['Already in BULIG Quest ('.$have[$k].').'];}
   elseif(isset($seen[$k]))$err('Same name as line '.$seen[$k].' in this file.');
   $seen[$k]=$row['line'];}
  $out[]=$row;
 }
 if(!$out)fail('The file has a header row but no teachers under it.');
 return $out;
}

function teacher_import_view():void{
 $p=$_SESSION['teacher_import']??null;$done=$_SESSION['teacher_import_done']??null;$step=(string)($_GET['step']??'');
 admin_heading('TEACHERS · ADD MANY','Add the whole team at once.','Upload a list from Excel. BULIG Quest makes every Teacher ID and starter password.','<a class="btn secondary" href="?page=accounts">'.icon('arrow','flip').'Back to teachers</a>');
 if(!cards_ready()){echo teacher_needs_018();return;}
 echo '<section class="card import-card" id="import">';
 if($step==='check'&&$p){
  $ok=count(array_filter($p['rows'],fn($r)=>$r['status']==='ok'));$skip=count(array_filter($p['rows'],fn($r)=>$r['status']==='skip'));$bad=count(array_filter($p['rows'],fn($r)=>$r['status']==='error'));
  echo '<div class="section-heading"><div><span class="eyebrow">STEP 2</span><h2>Check the list</h2></div></div><p class="import-summary"><strong>'.e($p['file']).'</strong> · <span class="pill ok">'.$ok.' ready</span> <span class="pill skip">'.$skip.' already in BULIG</span> <span class="pill bad">'.$bad.' need fixing</span></p>';
  if($bad)echo '<p class="muted">Rows that need fixing are left out. Fix them in your file and upload again, or make the ready accounts now and add the rest later.</p>';
  echo '<div class="tablewrap import-preview"><table><thead><tr><th>Line</th><th>Name</th><th>Sex</th><th>First section</th><th>Check</th></tr></thead><tbody>';
  foreach($p['rows'] as $r)echo '<tr class="row-'.$r['status'].'"><td>'.$r['line'].'</td><td>'.e($r['name']?:'—').'</td><td>'.e($r['sex']?ucfirst($r['sex']):'—').'</td><td>'.e($r['section']!==''?'Grade '.$r['grade'].' – '.$r['section']:'—').'</td><td><span class="pill '.($r['status']==='ok'?'ok':($r['status']==='skip'?'skip':'bad')).'">'.($r['status']==='ok'?'Ready':($r['status']==='skip'?'Skip':'Fix')).'</span>'.($r['notes']?'<small>'.e(implode(' ',$r['notes'])).'</small>':'').'</td></tr>';
  echo '</tbody></table></div><div class="import-actions">';
  if($ok)echo '<form method="post">'.csrf_field().'<input type="hidden" name="action" value="timport_confirm"><input type="hidden" name="token" value="'.e($p['token']).'">'.school_pick_field('School of these teachers').'<button class="btn primary">'.icon('check').'Create '.$ok.' teacher account'.($ok===1?'':'s').'</button></form>';
  echo '<form method="post">'.csrf_field().'<input type="hidden" name="action" value="timport_cancel"><button class="btn secondary">'.icon('replay').'Upload again</button></form></div></section>';return;
 }
 if($step==='done'&&$done){
  echo '<div class="section-heading"><div><span class="eyebrow">STEP 3</span><h2>'.count($done).' teacher account'.(count($done)===1?'':'s').' made</h2></div></div><p class="import-summary">Print a Teacher Pass for each teacher, or download the sign-in list. Each starter password works only until the teacher makes their own.</p>'
   .'<div class="import-actions"><a class="btn primary" href="?page=teacher_cards&amp;new=1">'.icon('download').'Print '.count($done).' Teacher Pass'.(count($done)===1?'':'es').'</a><a class="btn secondary" href="?page=teacher_logins">'.icon('download').'Download sign-in list (CSV)</a><a class="btn secondary" href="?page=add_teachers&amp;mode=many">Add more teachers</a></div>';
  echo '<div class="tablewrap import-preview"><table><thead><tr><th>Teacher ID</th><th>Name</th><th>First section</th></tr></thead><tbody>';foreach($done as $d)echo '<tr><td><strong>'.e($d['id']).'</strong></td><td>'.e($d['name']).'</td><td>'.e($d['section']?:'—').'</td></tr>';echo '</tbody></table></div></section>';return;
 }
 $how=($_GET['how']??'')==='file'?'file':'type';
 $tab=fn($k,$ic,$t)=>'<a href="?page=add_teachers&amp;mode=many&amp;how='.$k.'#import"'.($how===$k?' class="on" aria-current="page"':'').'>'.icon($ic).$t.'</a>';
 echo '<div class="section-heading"><div><span class="eyebrow">ADD MANY TEACHERS</span><h2>'.($how==='type'?'Type the list':'Upload a teacher list').'</h2></div>'.($how==='file'?'<a class="btn quiet small" href="?page=teacher_template">'.icon('download').'Download template</a>':'').'</div>';
 echo '<nav class="bk-tabs" aria-label="How to add the teachers">'.$tab('type','edit','Type the list').$tab('file','excel','Upload a file').'</nav>';
 if($how==='type'){echo teacher_typed_grid().'</section>'.names_script();return;}
 echo ''
  .'<ol class="import-steps"><li>Open the template in Excel. Fill in <strong>Last name</strong>, <strong>First name</strong>, <strong>Middle name</strong>, <strong>Extension</strong> (Jr., Sr., II … or blank) and <strong>Sex</strong> (M or F). <strong>Grade</strong> and <strong>Section</strong> are optional: BULIG Quest adds that section for the teacher.</li><li>Upload the .xlsx or .csv file. Nothing is saved yet. You will see every row first.</li><li>Press <strong>Create accounts</strong>, then print the Teacher Passes.</li></ol>'
  .'<div class="tablewrap import-preview tc-sample"><table><thead><tr><th>Last name</th><th>First name</th><th>Middle name</th><th>Extension <small>optional</small></th><th>Sex</th><th>Grade <small>optional</small></th><th>Section <small>optional</small></th></tr></thead><tbody><tr class="tc-what"><td>Family name</td><td>Given name</td><td>Middle name</td><td>Jr., Sr., II or blank</td><td>M or F</td><td>1 to 6</td><td>Section name</td></tr></tbody></table></div>'
  .'<form method="post" enctype="multipart/form-data" class="formgrid import-form">'.csrf_field().'<input type="hidden" name="action" value="timport_preview"><input type="hidden" name="MAX_FILE_SIZE" value="2097152"><label class="import-file">Teacher list file (.xlsx, .xls or .csv)<input type="file" name="teacher_list" accept=".csv,.xlsx,.xls,.txt,text/csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" required></label>'
  .'<div class="formend"><small>Up to '.IMPORT_MAX_ROWS.' teachers, 2 MB. Teachers already in BULIG Quest (same name) are skipped.</small><button class="btn primary">'.icon('check').'Check the list</button></div></form></section>';
}
/** "Type the list" for teachers: one row per teacher, like the pupils' list. Enter goes to the next teacher; assets/names.js
   checks each row while typing. Rows that need fixing come back here with the server's note (nothing is saved until every row is right). */
function teacher_typed_grid():string{
 $back=$_SESSION['teacher_typed']??null;unset($_SESSION['teacher_typed']);$rows=$back['rows']??[];$notes=$back['notes']??[];
 $h='<form method="post" class="bk-form" data-bk data-who="teacher" data-mode="one">'.csrf_field().'<input type="hidden" name="action" value="timport_typed">'
  .'<div class="bk-top">'.school_pick_field('School of these teachers',(int)($back['school']??0)).'</div><p class="sx-hint">Grade and Section are optional: BULIG Quest adds that section for the teacher. Each teacher gets a Teacher ID and a starter password.</p>';
 $h.='<div class="bk-gridwrap"><table class="bk-grid bk-tgrid"><thead><tr><th>#</th><th>Last name</th><th>First name</th><th>Middle name</th><th class="c-ext">Ext.</th><th class="c-sex">Sex</th><th class="c-gr">Grade <small>optional</small></th><th class="c-tsec">Section <small>optional</small></th><th class="c-st"><span class="sr-only">Check</span></th></tr></thead><tbody data-bk-body>';
 for($i=0,$n=max(10,count($rows));$i<$n;$i++)$h.=teacher_typed_row($i,$rows[$i]??[],$notes[$i]??'');
 $h.='</tbody></table></div><template data-bk-tpl>'.teacher_typed_row(-1,[],'').'</template>';
 return $h.'<div class="bk-foot"><small>Press <b>Enter</b> for the next teacher. Empty rows are skipped. Teachers already in BULIG Quest (same name) are left out. <span data-bk-count aria-live="polite"></span></small><span class="bk-btns"><button type="button" class="btn secondary" data-bk-more>+ 10 more rows</button><button class="btn primary" data-bk-go>'.icon('check').'<span data-bk-label>Create teacher accounts</span></button></span></div></form>';
}
function teacher_typed_row(int $i,array $r,string $note):string{
 $n=$i<0?'__':(string)$i;$v=fn($k)=>e((string)($r[$k]??''));$ext=(string)($r[3]??'');$sex=strtoupper((string)($r[4]??''));$gr=(int)($r[5]??0);
 $in=fn($k,$col,$lab,$extra='')=>'<td data-l="'.$lab.'"><input name="t['.$col.']['.$n.']" value="'.$v($k).'" maxlength="60" autocomplete="off" aria-label="'.$lab.', teacher '.($i<0?'':$i+1).'"'.$extra.'></td>';
 $o='<option value="">—</option>';foreach(NAME_EXTS as $x)$o.='<option value="'.$x.'"'.(name_ext_norm($ext)===$x?' selected':'').'>'.$x.'</option>';
 $mf='';foreach(['M'=>'Male','F'=>'Female'] as $k=>$t)$mf.='<label><input type="radio" name="t[sex]['.$n.']" value="'.$k.'"'.(in_array($sex,[$k,strtoupper($t)],true)?' checked':'').' aria-label="'.$t.'"><b>'.$k.'</b></label>';
 $g='<option value="">—</option>'.grade_options((int)$gr,$GLOBALS['bulig_add_grades']??null);
 return '<tr data-bk-row'.($note!==''?' class="err"':'').'><td data-bk-n>'.($i<0?'':$i+1).'</td>'.$in(0,'last','Last name',$i===0?' placeholder="Type here…"':'').$in(1,'first','First name').$in(2,'middle','Middle name')
  .'<td class="c-ext" data-l="Ext."><select name="t[ext]['.$n.']" aria-label="Extension">'.$o.'</select></td><td class="c-sex" data-l="Sex"><span class="bk-sex">'.$mf.'</span></td>'
  .'<td class="c-gr" data-l="Grade (optional)"><select name="t[grade]['.$n.']" aria-label="Grade">'.$g.'</select></td>'.$in(6,'section','Section (optional)').'<td class="c-st" data-bk-st>'.($note!==''?'<span class="bad">'.e($note).'</span>':'').'</td></tr>';
}

/** Make the accounts for every ready row (an uploaded file or the typed list), then show the done step. */
function teacher_import_create(array $rows,string $file):never{
 if(!cards_ready())fail('Import database/migrations/018_pupil_cards.sql first.');
 $done=[];db()->beginTransaction();try{
  $have=[];foreach(rows("SELECT name FROM users WHERE role='teacher'") as $t)$have[ck_name_key((string)$t['name'])]=1;
  foreach($rows as $r){if($r['status']!=='ok'||isset($have[ck_name_key($r['name'])]))continue;
   $c=teacher_create($r['name'],(string)$r['sex']);name_parts_save($c['id'],$r['parts']??null);$have[ck_name_key($r['name'])]=1;$label='';
   if($r['section']!==''){q('INSERT INTO sections(teacher_id,grade_level,name) VALUES(?,?,?)',[$c['id'],$r['grade'],$r['section']]);$label='Grade '.$r['grade'].' – '.$r['section'];}
   $done[]=['uid'=>$c['id'],'id'=>$c['public'],'name'=>$r['name'],'section'=>$label,'pw'=>$c['pw']];}
  audit('import_teachers',count($done).' from '.$file);db()->commit();
 }catch(Throwable $e){if(db()->inTransaction())db()->rollBack();throw $e;}
 unset($_SESSION['teacher_import']);$_SESSION['teacher_import_done']=$done;
 $skip=count(array_filter($rows,fn($r)=>$r['status']==='skip'));
 flash(count($done).' teacher account'.(count($done)===1?'':'s').' made.'.($skip?' '.$skip.' already in BULIG Quest '.($skip===1?'was':'were').' left out.':'').' Print their Teacher Passes.');go('?page=teacher_import&step=done');
}

function teacher_import_download(string $page):never{
 require_role('admin');
 if($page==='teacher_template'){header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="BULIG-teacher-list-template.csv"');
  echo "\xEF\xBB\xBF".'Last name,First name,Middle name,Extension,Sex,Grade,Section'."\r\n";exit;}
 $done=$_SESSION['teacher_import_done']??[];if(!$done)fail('There is no finished import to download.',404);
 header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="BULIG-new-teacher-logins.csv"');$h=fopen('php://output','w');fwrite($h,"\xEF\xBB\xBF");
 fputcsv($h,['Teacher ID','Name','First section','Starter password'],',','"','\\');foreach($done as $d)fputcsv($h,[$d['id'],$d['name'],$d['section'],$d['pw']],',','"','\\');exit;
}

/* ---------- "Make your own password" (a teacher's first sign-in) ---------- */
function teacher_first_password_view(array $u):void{
 $first=explode(' ',trim((string)$u['name']))[0];$err=(string)($_SESSION['tp_err']??'');unset($_SESSION['tp_err']);
 $hello=$_SESSION['hello']??null;unset($_SESSION['hello']);head('Make your password','login-page tp-page lsky-'.login_daypart());if($hello)$_SESSION['hello']=$hello;  // the welcome screen waits for the dashboard
 $eye=fn($id)=>str_replace('data-password="password"','data-password="'.$id.'"',login_eye_button());
 echo login_shell_open(false,'teacher');notice();
 echo '<div class="login-top"><span class="tp-lock">'.icon('lock').'ONE MORE STEP</span><form method="post" class="tp-out">'.csrf_field().'<input type="hidden" name="action" value="logout"><button type="submit" class="admin-pill">'.icon('logout').'Sign out</button></form></div>'
  .'<img class="tp-who" src="'.teacher_char((int)$u['id']).'" alt=""><h2>Welcome to BULIG Quest, <br>'.e($first).'!</h2><p class="muted tp-why">Before you start, make your own password. Only you will know it.</p>';
 if($err!=='')echo '<div class="pin-error" role="alert">'.icon('alert').'<span>'.e($err).'</span></div>';
 echo '<form method="post" class="stack" data-tp-form>'.csrf_field().'<input type="hidden" name="action" value="first_password">'
  .'<label>New password<span class="password-field"><input id="tp-new" name="new_password" type="password" required minlength="8" maxlength="72" autocomplete="new-password" placeholder="Letters and numbers">'.$eye('tp-new').'</span></label>'
  .'<label>Type it again<span class="password-field"><input id="tp-again" name="confirm_password" type="password" required minlength="8" maxlength="72" autocomplete="new-password" placeholder="The same password">'.$eye('tp-again').'</span></label>'
  .'<ul class="tp-rules" data-tp-rules><li data-r="len">'.icon('check').'At least 8 characters</li><li data-r="mix">'.icon('check').'Letters and numbers</li><li data-r="same">'.icon('check').'Both boxes match</li></ul>'
  .'<button class="btn primary full" type="submit">Save my password '.icon('arrow').'</button></form>'
  .'<p class="tp-note">'.icon('info').'<span>Next time, scan your Teacher Pass to fill in your Teacher ID, then type this password.</span></p>';
 echo login_shell_close();
}

function teacher_account_action(string $action):never{
 if($action==='first_password'){
  $u=require_role('teacher');if(!teacher_must_change($u))go('?page=dashboard');
  $back=function(string $m):never{$_SESSION['tp_err']=$m;go('?page=dashboard');};
  $new=(string)($_POST['new_password']??'');
  if(strlen($new)<8||strlen($new)>72)$back('Use 8 to 72 characters.');
  if(!preg_match('/[A-Za-z]/',$new)||!preg_match('/[0-9]/',$new))$back('Use both letters and numbers.');
  if($new!==(string)($_POST['confirm_password']??''))$back('The two passwords are not the same. Type them again.');
  if(password_verify($new,(string)$u['password_hash']))$back('Make a new password. The starter password cannot be used again.');
  q('UPDATE users SET password_hash=? WHERE id=?',[password_hash($new,PASSWORD_DEFAULT),$u['id']]);card_forget_starter((int)$u['id']);saved_login_clear((int)$u['id']);
  session_regenerate_id(true);$_SESSION['teacher_welcome']=1;audit('first_password','teacher');flash('Your password is saved. Welcome to BULIG Quest!');go('?page=dashboard');
 }
 $u=require_role('admin');
 if($action==='admin_teacher_starter'){
  if(!cards_ready())fail('Import database/migrations/018_pupil_cards.sql first.');
  $t=admin_teacher((int)($_POST['id']??0));$n=card_issue((int)$t['id'],true);saved_login_clear((int)$t['id']);try{q('DELETE FROM remember_tokens WHERE user_id=?',[$t['id']]);}catch(Throwable $e){}
  audit('admin_teacher_starter',(string)$t['public_id']);flash('New starter password for '.$t['name'].' ('.$t['public_id'].'): '.$n['pw'].'. The old password and QR code no longer work. Print the new Teacher Pass.');
  go(($_POST['back']??'')==='cards'?'?page=teacher_cards&t='.(int)$t['id']:'?page=accounts');
 }
 if($action==='timport_preview'){
  if(!cards_ready())fail('Import database/migrations/018_pupil_cards.sql first.');
  $f=$_FILES['teacher_list']??null;
  if(!$f||($f['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)fail(($f['error']??0)===UPLOAD_ERR_INI_SIZE||($f['error']??0)===UPLOAD_ERR_FORM_SIZE?'The file is too big. Keep it under 2 MB.':'Choose a CSV or Excel file to upload.');
  if($f['size']>2*1024*1024)fail('The file is too big. Keep it under 2 MB.');
  $checked=teacher_import_check(import_read_file($f['tmp_name'],(string)$f['name']));
  $_SESSION['teacher_import']=['token'=>bin2hex(random_bytes(16)),'file'=>mb_substr(basename((string)$f['name']),0,120),'rows'=>$checked];unset($_SESSION['teacher_import_done']);
  go('?page=teacher_import&step=check');
 }
 if($action==='timport_typed'){
  if(!cards_ready())fail('Import database/migrations/018_pupil_cards.sql first.');
  if(isset($_POST['school_id']))school_use((int)$_POST['school_id']);
  $t=(array)($_POST['t']??[]);$keys=['last','first','middle','ext','sex','grade','section'];$n=0;foreach($keys as $k)foreach(array_keys((array)($t[$k]??[])) as $i)$n=max($n,(int)$i+1);
  if($n>IMPORT_MAX_ROWS)fail('Type up to '.IMPORT_MAX_ROWS.' teachers at a time.');
  $typed=[];$list=[['Last name','First name','Middle name','Extension','Sex','Grade','Section']];
  for($i=0;$i<$n;$i++){$r=[];foreach($keys as $k)$r[]=mb_substr(trim((string)(((array)($t[$k]??[]))[$i]??'')),0,80);
   if($r[0].$r[1].$r[2].$r[6]===''){$r=array_fill(0,7,'');}   // only M/F or a grade picked: an empty row
   $typed[]=$r;$list[]=$r;}
  if(!array_filter($typed,fn($r)=>implode('',$r)!==''))fail('Type at least one teacher first.');
  $checked=teacher_import_check($list);
  foreach($checked as &$c){$c['line']--;$c['notes']=array_map(fn($x)=>preg_replace_callback('/line (\d+) in this file/',fn($m)=>'row '.((int)$m[1]-1).' of this list',$x),$c['notes']);}unset($c);   // row numbers of the list, not of a file
  $bad=array_filter($checked,fn($r)=>$r['status']==='error');
  if($bad){$_SESSION['teacher_typed']=['rows'=>$typed,'notes'=>array_column(array_map(fn($r)=>[$r['line']-1,implode(' ',$r['notes'])],$bad),1,0),'school'=>(int)($_POST['school_id']??0)];
   flash(count($bad).' '.(count($bad)===1?'row needs':'rows need').' fixing. Nothing was saved yet: fix the rows marked in red, then press Create again.');go('?page=add_teachers&mode=many&how=type#import');}
  unset($_SESSION['teacher_typed']);teacher_import_create($checked,'the typed list');
 }
 if($action==='timport_cancel'){unset($_SESSION['teacher_import']);flash('Cancelled. No accounts were made.');go('?page=teacher_import');}
 if($action==='timport_confirm'){if(isset($_POST['school_id']))school_use((int)$_POST['school_id']);
  $p=$_SESSION['teacher_import']??null;if(!$p||!hash_equals($p['token'],(string)($_POST['token']??'')))fail('This list has expired. Upload it again.');
  if(!cards_ready())fail('Import database/migrations/018_pupil_cards.sql first.');
  teacher_import_create($p['rows'],$p['file']);
 }
 fail('Unknown action.');
}
