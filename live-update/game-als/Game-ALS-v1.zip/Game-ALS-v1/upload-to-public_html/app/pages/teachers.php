<?php
$me = need('admin');
$newPass = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = $_POST['do'] ?? '';
    if ($do === 'add') {
        $fn = trim((string)$_POST['first_name']); $ln = trim((string)$_POST['last_name']); $un = strtolower(trim((string)$_POST['username']));
        if ($fn === '' || $ln === '' || !preg_match('/^[a-z0-9._-]{3,40}$/', $un)) flash('Fill in the name, and a username of 3–40 letters, numbers, dot, dash or underscore.', 'err');
        elseif (val('SELECT 1 FROM users WHERE username = ?', [$un])) flash('That username is already taken.', 'err');
        else {
            $pw = make_password();
            q('INSERT INTO users (role, username, password_hash, first_name, middle_name, last_name, email, created_by) VALUES ("teacher", ?, ?, ?, ?, ?, ?, ?)',
              [$un, password_hash($pw, PASSWORD_DEFAULT), $fn, trim((string)($_POST['middle_name'] ?? '')), $ln, trim((string)($_POST['email'] ?? '')), $me['id']]);
            $tid = (int)db()->lastInsertId();
            foreach ((array)($_POST['clcs'] ?? []) as $c) q('INSERT IGNORE INTO teacher_clc VALUES (?, ?)', [$tid, (int)$c]);
            $_SESSION['shown_pw'] = [$un, $pw];
            flash('Teacher account made. Give them the username and password below.');
        }
        redirect('teachers');
    }
    $t = one('SELECT * FROM users WHERE id = ? AND role = "teacher"', [(int)($_POST['id'] ?? 0)]);
    if ($t) {
        if ($do === 'clcs') {
            q('DELETE FROM teacher_clc WHERE teacher_id = ?', [$t['id']]);
            foreach ((array)($_POST['clcs'] ?? []) as $c) q('INSERT IGNORE INTO teacher_clc VALUES (?, ?)', [$t['id'], (int)$c]);
            flash('CLCs updated for ' . full_name($t) . '.');
        } elseif ($do === 'reset') {
            $pw = make_password();
            q('UPDATE users SET password_hash = ?, must_change = 1 WHERE id = ?', [password_hash($pw, PASSWORD_DEFAULT), $t['id']]);
            $_SESSION['shown_pw'] = [$t['username'], $pw];
            flash('New password made for ' . full_name($t) . '.');
        } elseif ($do === 'toggle') {
            q('UPDATE users SET active = 1 - active WHERE id = ?', [$t['id']]);
            flash(full_name($t) . ($t['active'] ? ' can no longer sign in.' : ' can sign in again.'));
        }
    }
    redirect('teachers');
}
$shown = $_SESSION['shown_pw'] ?? null; unset($_SESSION['shown_pw']);
$teachers = all('SELECT u.*, (SELECT GROUP_CONCAT(clc_id) FROM teacher_clc WHERE teacher_id = u.id) clc_ids FROM users u WHERE role = "teacher" ORDER BY active DESC, last_name, first_name');
render('teachers', ['title' => 'Teachers', 'teachers' => $teachers, 'clcs' => all('SELECT * FROM clcs ORDER BY name'), 'shown' => $shown]);
