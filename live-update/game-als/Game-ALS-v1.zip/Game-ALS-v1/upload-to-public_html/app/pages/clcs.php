<?php
need('admin');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = $_POST['do'] ?? '';
    $name = trim((string)($_POST['name'] ?? '')); $mun = trim((string)($_POST['municipality'] ?? '')); $dist = trim((string)($_POST['district'] ?? ''));
    if ($do === 'add' && $name !== '') { q('INSERT INTO clcs (name, municipality, district) VALUES (?, ?, ?)', [$name, $mun, $dist]); flash('CLC added.'); }
    elseif ($do === 'save' && $name !== '') { q('UPDATE clcs SET name = ?, municipality = ?, district = ? WHERE id = ?', [$name, $mun, $dist, (int)$_POST['id']]); flash('CLC saved.'); }
    elseif ($do === 'del') {
        $id = (int)$_POST['id'];
        if (val('SELECT COUNT(*) FROM users WHERE clc_id = ?', [$id])) flash('This CLC still has learners. Move them first.', 'err');
        else { q('DELETE FROM teacher_clc WHERE clc_id = ?', [$id]); q('DELETE FROM clcs WHERE id = ?', [$id]); flash('CLC removed.'); }
    }
    redirect('clcs');
}
$rows = all('SELECT c.*, (SELECT COUNT(*) FROM users WHERE clc_id = c.id AND role = "learner") learners,
  (SELECT GROUP_CONCAT(CONCAT(u.first_name, " ", u.last_name) SEPARATOR ", ") FROM teacher_clc t JOIN users u ON u.id = t.teacher_id WHERE t.clc_id = c.id) teachers
  FROM clcs c ORDER BY municipality, district, name');
render('clcs', ['title' => 'CLCs', 'rows' => $rows]);
