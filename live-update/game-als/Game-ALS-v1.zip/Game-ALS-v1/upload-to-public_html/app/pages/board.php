<?php
$u = need();
$where = ["l.role = 'learner'", 'l.active = 1']; $args = []; $scope = '';
$clcs = []; $f = ['clc' => (int)($_GET['clc'] ?? 0), 'mun' => (string)($_GET['mun'] ?? ''), 'dist' => (string)($_GET['dist'] ?? ''), 'grade' => (string)($_GET['grade'] ?? '')];
if ($u['role'] === 'learner') {
    $where[] = 'l.grade <=> ?'; $args[] = $u['grade'];
    $scope = GRADES[$u['grade'] ?: 'ELEM'] . ' learners';
} elseif ($u['role'] === 'teacher') {
    $ids = teacher_clc_ids((int)$u['id']) ?: [0];
    $clcs = all('SELECT * FROM clcs WHERE id IN (' . implode(',', $ids) . ') ORDER BY name');
    if ($f['clc'] && in_array($f['clc'], $ids, true)) { $where[] = 'l.clc_id = ?'; $args[] = $f['clc']; }
    else $where[] = 'l.clc_id IN (' . implode(',', $ids) . ')';
    $scope = 'Your CLCs';
} else {
    $clcs = all('SELECT * FROM clcs ORDER BY name');
    if ($f['clc']) { $where[] = 'l.clc_id = ?'; $args[] = $f['clc']; }
    if ($f['mun'] !== '') { $where[] = 'c.municipality = ?'; $args[] = $f['mun']; }
    if ($f['dist'] !== '') { $where[] = 'c.district = ?'; $args[] = $f['dist']; }
    $scope = 'Whole division';
}
if ($u['role'] !== 'learner' && isset(GRADES[$f['grade']])) { $where[] = 'l.grade = ?'; $args[] = $f['grade']; }
$rows = all('SELECT l.id, l.first_name, l.middle_name, l.last_name, l.grade, c.name clc, c.municipality,
    COALESCE(SUM(p.best_correct * 10 + p.passed * 50), 0) pts, COALESCE(SUM(p.passed), 0) passed,
    (SELECT COUNT(*) FROM certificates x WHERE x.user_id = l.id) certs
  FROM users l LEFT JOIN clcs c ON c.id = l.clc_id LEFT JOIN progress p ON p.user_id = l.id
  WHERE ' . implode(' AND ', $where) . ' GROUP BY l.id HAVING pts > 0 ORDER BY pts DESC, passed DESC, l.last_name LIMIT 100', $args);
render('board', ['title' => 'Leaderboard', 'rows' => $rows, 'scope' => $scope, 'clcs' => $clcs, 'f' => $f,
  'muns' => $u['role'] === 'admin' ? array_column(all("SELECT DISTINCT municipality FROM clcs WHERE municipality <> '' ORDER BY 1"), 'municipality') : [],
  'dists' => $u['role'] === 'admin' ? array_column(all("SELECT DISTINCT district FROM clcs WHERE district <> '' ORDER BY 1"), 'district') : []]);
