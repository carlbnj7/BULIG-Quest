<div class="page-head"><div><h1>Community Learning Centers</h1><p class="muted">Municipality and district are used for the leaderboards and reports.</p></div></div>
<form method="post" class="card form inline-form"><?= csrf_field() ?><input type="hidden" name="do" value="add">
  <label>CLC name<input name="name" required></label><label>Municipality<input name="municipality" list="muns"></label><label>District<input name="district" list="dists"></label><button class="btn primary"><?= icon('plus', 16) ?> Add CLC</button>
</form>
<datalist id="muns"><?php foreach (array_unique(array_filter(array_column($rows, 'municipality'))) as $m): ?><option value="<?= e($m) ?>"><?php endforeach; ?></datalist>
<datalist id="dists"><?php foreach (array_unique(array_filter(array_column($rows, 'district'))) as $m): ?><option value="<?= e($m) ?>"><?php endforeach; ?></datalist>
<div class="card"><table class="tbl">
<thead><tr><th>CLC</th><th>Municipality</th><th>District</th><th>Teachers</th><th>Learners</th><th></th></tr></thead><tbody>
<?php foreach ($rows as $r): $f = 'f' . (int)$r['id']; ?>
<tr>
  <td><input form="<?= $f ?>" name="name" value="<?= e($r['name']) ?>" required></td>
  <td><input form="<?= $f ?>" name="municipality" value="<?= e($r['municipality']) ?>" list="muns"></td>
  <td><input form="<?= $f ?>" name="district" value="<?= e($r['district']) ?>" list="dists"></td>
  <td class="small"><?= e($r['teachers'] ?: '—') ?></td><td><?= (int)$r['learners'] ?></td>
  <td class="acts-cell">
    <form id="<?= $f ?>" method="post"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn sm">Save</button></form>
    <form method="post" data-confirm="Remove this CLC?"><?= csrf_field() ?><input type="hidden" name="do" value="del"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn sm ghost">Remove</button></form>
  </td>
</tr>
<?php endforeach; ?>
<?php if (!$rows): ?><tr><td colspan="6" class="muted">No CLCs yet. Add the first one above.</td></tr><?php endif; ?>
</tbody></table></div>
