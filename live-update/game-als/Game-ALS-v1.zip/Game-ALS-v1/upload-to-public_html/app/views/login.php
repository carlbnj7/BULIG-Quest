<?php
$orbit = '';
$i = 0; $n = count(STRANDS);
foreach (STRANDS as $code => [$ls, $short, $name, $col, $ic]) {
    $orbit .= '<span class="orb o' . $i . ' c-' . e(strtolower($code)) . '" title="' . e($ls . ' ' . $short) . '">' . icon($ic, 17) . '</span>';
    $i++;
}
?>
<div class="auth-wrap">
  <section class="auth-hero">
    <div class="auth-bar">
      <div class="brand-l"><b>Game<i>ALS</i></b><small>ALTERNATIVE LEARNING SYSTEM</small></div>
      <button type="button" class="seg-toggle" data-theme-toggle aria-label="Switch light or dark"><span class="s-sun"><?= icon('sun', 15) ?></span><span class="s-moon"><?= icon('moon', 14) ?></span></button>
    </div>
    <div class="emblem">
      <div class="ring"></div><div class="core-bg"></div>
      <?= $orbit ?>
      <div class="core"><?= icon('game', 44) ?></div>
    </div>
    <div class="hero-copy">
      <h2>Learn, play, and level up.</h2>
      <p>Seven Learning Strands. Three levels each. Earn your Certificate of Readiness.</p>
    </div>
  </section>
  <section class="auth-sheet">
    <div class="grab"></div>
    <div class="sheet-head">
      <div><h1>Welcome back</h1><p>Sign in to continue your review.</p></div>
      <span class="chip">Elem · JHS</span>
    </div>
    <?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
    <form method="post" action="<?= url('login') ?>" class="auth-form" autocomplete="on">
      <?= csrf_field() ?>
      <label for="u">Username or Learner ID</label>
      <div class="field"><?= icon('user', 18) ?><input id="u" name="username" value="<?= e($old) ?>" required autocomplete="username" autocapitalize="none" spellcheck="false"></div>
      <label for="pw">Password</label>
      <div class="field"><?= icon('key', 18) ?><input id="pw" type="password" name="password" required autocomplete="current-password"><button type="button" class="peek" data-peek="pw">Show</button></div>
      <button class="btn primary big"><span>Sign in</span><?= icon('arrow', 18) ?></button>
    </form>
    <p class="muted center small">New here? Your ALS teacher creates your account.<br>Forgot your password? Ask your teacher to give you a new one.</p>
    <div class="auth-foot"><img src="assets/img/division.webp" alt="" width="34" height="34"><span><?= e(setting('division_name', 'Division of Bukidnon')) ?><br><small>Department of Education</small></span></div>
  </section>
</div>
<script src="assets/js/auth.js?v=1"></script>
