<?php $u = me(); ?>
<section class="hello">
  <div>
    <p class="eyebrow"><?= e(GRADES[$u['grade'] ?: 'ELEM']) ?><?= $clc ? ' · ' . e($clc['name']) : '' ?></p>
    <h1>Hi, <?= e($u['first_name']) ?>.</h1>
    <p class="muted">Pass each activity with 75% or more to move ahead.</p>
  </div>
  <div class="stats3">
    <div><b><?= number_format($points) ?></b><span>Points</span></div>
    <div><b><?= $passed ?><small>/63</small></b><span>Activities passed</span></div>
    <div><b><?= $certs ?></b><span>Certificates</span></div>
  </div>
</section>

<?php if ($playing): $st = STRANDS[$playing['strand']]; ?>
<a class="resume" href="<?= url('play', ['s' => $playing['strand'], 'l' => $playing['level'], 'a' => $playing['activity']]) ?>">
  <span class="sq c-<?= e(strtolower($playing['strand'])) ?>"><?= icon($st[4], 22) ?></span>
  <span class="grow"><small>Continue where you stopped</small><b><?= e($st[0] . ' ' . $st[1]) ?> · Level <?= (int)$playing['level'] ?> · Activity <?= (int)$playing['activity'] ?></b><em>Item <?= (int)$playing['pos'] + 1 ?> of <?= count(explode(',', $playing['item_ids'])) ?></em></span>
  <span class="btn primary"><?= icon('play', 16) ?> Resume</span>
</a>
<?php elseif ($next): $st = STRANDS[$next[0]]; ?>
<a class="resume" href="<?= url('strand', ['s' => $next[0]]) ?>">
  <span class="sq c-<?= e(strtolower($next[0])) ?>"><?= icon($st[4], 22) ?></span>
  <span class="grow"><small>Up next</small><b><?= e($st[0] . ' ' . $st[1]) ?> · Level <?= $next[1] ?> · Activity <?= $next[2] ?></b><em>Items <?= activity_range($next[2]) ?></em></span>
  <span class="btn primary"><?= icon('play', 16) ?> Start</span>
</a>
<?php endif; ?>

<h2 class="sec">Learning Strands</h2>
<div class="strands">
<?php foreach (STRANDS as $code => [$ls, $short, $name, $col, $ic]):
    $done = strand_done_count($pm, $code); $pct = (int)round($done / 9 * 100); ?>
  <a class="strand c-<?= e(strtolower($code)) ?>" href="<?= url('strand', ['s' => $code]) ?>">
    <div class="st-top">
      <span class="sq c-<?= e(strtolower($code)) ?>"><?= icon($ic, 22) ?></span>
      <span class="st-t"><small><?= e($ls) ?></small><b><?= e($name) ?></b></span>
    </div>
    <progress max="9" value="<?= $done ?>" class="c-<?= e(strtolower($code)) ?>"></progress>
    <div class="st-foot">
      <div class="lv-chips">
        <?php for ($l = 1; $l <= 3; $l++): $open = level_open($pm, $code, $l); $ld = level_done($pm, $code, $l); ?>
          <span class="lv <?= $ld ? 'done' : ($open ? 'open' : 'locked') ?>" title="Level <?= $l ?>: <?= LEVELS[$l] ?>"><?= $ld ? icon('check', 12) : (!$open ? icon('lock', 11) : '') ?>L<?= $l ?></span>
        <?php endfor; ?>
      </div>
      <span class="muted small"><?= $pct ?>%</span>
    </div>
    <?php if (empty($counts[$code])): ?><span class="soon">Questions coming soon</span><?php endif; ?>
  </a>
<?php endforeach; ?>
</div>
