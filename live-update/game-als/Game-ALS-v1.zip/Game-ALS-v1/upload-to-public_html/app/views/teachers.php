<div class="page-head"><div><h1>Teachers</h1><p class="muted">Only the admin makes teacher accounts. Teachers then make their learners' accounts.</p></div></div>
<?php if ($shown): ?><div class="pw-slip"><b>Username:</b> <code><?= e($shown[0]) ?></code> <b>Password:</b> <code><?= e($shown[1]) ?></code><small>This password shows only once. They make their own password on first sign-in.</small></div><?php endif; ?>
<details class="card add" <?= !$teachers ? 'open' : '' ?>>
  <summary><?= icon('plus', 18) ?> Add a teacher</summary>
  <form method="post" class="form grid2"><?= csrf_field() ?><input type="hidden" name="do" value="add">
    <label>First name<input name="first_name" required></label>
    <label>Middle name<input name="middle_name"></label>
    <label>Last name<input name="last_name" required></label>
    <label>Username<input name="username" required pattern="[A-Za-z0-9._\-]{3,40}" placeholder="e.g. jdelacruz"></label>
    <label>Email (optional)<input type="email" name="email"></label>
    <fieldset class="span2"><legend>CLCs they handle</legend><div class="checks"><?php foreach ($clcs as $c): ?><label class="ck"><input type="checkbox" name="clcs[]" value="<?= (int)$c['id'] ?>"> <?= e($c['name']) ?></label><?php endforeach; ?><?= !$clcs ? '<span class="muted small">Add CLCs first on the CLCs page.</span>' : '' ?></div></fieldset>
    <button class="btn primary">Make account</button>
  </form>
</details>
<div class="card">
<table class="tbl">
<thead><tr><th>Teacher</th><th>Username</th><th>CLCs</th><th>Last sign-in</th><th></th></tr></thead>
<tbody>
<?php $cn = array_column($clcs, 'name', 'id'); foreach ($teachers as $t): $ids = $t['clc_ids'] ? explode(',', $t['clc_ids']) : []; ?>
<tr class="<?= $t['active'] ? '' : 'off' ?>">
  <td><b><?= e(full_name($t)) ?></b><?= $t['active'] ? '' : ' <span class="pill">Turned off</span>' ?></td>
  <td><?= e($t['username']) ?></td>
  <td>
    <details class="inline"><summary><?= $ids ? e(implode(', ', array_map(fn($i) => $cn[$i] ?? '?', $ids))) : '<span class="muted">None</span>' ?></summary>
      <form method="post" class="checks"><?= csrf_field() ?><input type="hidden" name="do" value="clcs"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
        <?php foreach ($clcs as $c): ?><label class="ck"><input type="checkbox" name="clcs[]" value="<?= (int)$c['id'] ?>" <?= in_array((string)$c['id'], $ids, true) ? 'checked' : '' ?>> <?= e($c['name']) ?></label><?php endforeach; ?>
        <button class="btn sm">Save</button></form></details>
  </td>
  <td class="muted small"><?= $t['last_login'] ? e(date('M j, Y', strtotime($t['last_login']))) : 'Never' ?></td>
  <td class="acts-cell">
    <form method="post" data-confirm="Make a new password for this teacher?"><?= csrf_field() ?><input type="hidden" name="do" value="reset"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>"><button class="btn sm ghost">New password</button></form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="toggle"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>"><button class="btn sm ghost"><?= $t['active'] ? 'Turn off' : 'Turn on' ?></button></form>
  </td>
</tr>
<?php endforeach; ?>
<?php if (!$teachers): ?><tr><td colspan="5" class="muted">No teachers yet.</td></tr><?php endif; ?>
</tbody></table></div>
