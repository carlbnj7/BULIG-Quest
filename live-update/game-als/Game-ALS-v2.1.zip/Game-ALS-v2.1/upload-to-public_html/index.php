<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require __DIR__ . '/app/game.php';
require __DIR__ . '/app/art.php';

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: same-origin');
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; font-src 'self'; frame-ancestors 'self'; form-action 'self'; base-uri 'self'");

start_session();
$page = preg_replace('/[^a-z_]/', '', (string)($_GET['p'] ?? ''));
if ($page === '') $page = me() ? 'home' : 'login';
$file = ROOT . '/app/pages/' . $page . '.php';
if (!is_file($file)) { http_response_code(404); render('error', ['title' => 'Page not found', 'msg' => 'That page does not exist.']); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') check_csrf();
// Make a new password first when the account still uses the one it was given.
$u = me();
if ($u && $u['must_change'] && !in_array($page, ['password', 'logout', 'api'], true)) redirect('password');
try {
    require $file;
} catch (Throwable $ex) {
    error_log('[Game ALS] ' . $ex->getMessage() . ' @ ' . $ex->getFile() . ':' . $ex->getLine());
    http_response_code(500);
    if ($page === 'api') { header('Content-Type: application/json'); echo json_encode(['error' => 'Something went wrong. Please try again.']); exit; }
    render('error', ['title' => 'Something went wrong', 'msg' => !empty($CFG['debug']) ? $ex->getMessage() : 'Please try again. If it keeps happening, tell your teacher or the admin.']);
}
