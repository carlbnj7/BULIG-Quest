(function () {
  var k = 'gameals-theme', t = null;
  try { t = localStorage.getItem(k); } catch (e) {}
  if (!t) t = (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', t);
  document.addEventListener('click', function (ev) {
    var b = ev.target.closest('[data-theme-toggle]'); if (!b) return;
    var n = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', n);
    try { localStorage.setItem(k, n); } catch (e) {}
  });
  document.addEventListener('submit', function (ev) {
    var m = ev.target.getAttribute('data-confirm');
    if (m && !confirm(m)) ev.preventDefault();
  });
  // PIN boxes: numbers only, 4 at most.
  document.addEventListener('input', function (ev) {
    var i = ev.target; if (!i.matches || !i.matches('[data-pin]')) return;
    var v = i.value.replace(/\D/g, '').slice(0, 4); if (v !== i.value) i.value = v;
  });
  // Offline helper (needs https, or localhost while testing).
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () {}); });
  }
  // Install Game ALS like an app.
  var standalone = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
  var ios = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  var deferred = null;
  function showInstall() {
    if (standalone) return;
    document.querySelectorAll('[data-install]').forEach(function (b) { if (deferred || ios) b.hidden = false; });
  }
  window.addEventListener('beforeinstallprompt', function (ev) { ev.preventDefault(); deferred = ev; showInstall(); });
  window.addEventListener('appinstalled', function () { deferred = null; document.querySelectorAll('[data-install]').forEach(function (b) { b.hidden = true; }); });
  document.addEventListener('DOMContentLoaded', showInstall);
  document.addEventListener('click', function (ev) {
    var b = ev.target.closest('[data-install]'); if (!b) return;
    if (deferred) { deferred.prompt(); deferred.userChoice.then(function () { deferred = null; }); return; }
    var h = document.querySelector('[data-install-ios]'); if (h) h.hidden = !h.hidden;
  });
  document.addEventListener('click', function (ev) {
    var p = ev.target.closest('[data-print]'); if (p) { ev.preventDefault(); window.print(); }
  });
})();
